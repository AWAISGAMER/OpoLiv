
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class AuthService {
  AuthService._();
  static final instance = AuthService._();

  final _auth = FirebaseAuth.instance;
  final _db = FirebaseFirestore.instance;

  Stream<User?> get authStateChanges => _auth.authStateChanges();

  Future<UserCredential> anonymousLogin() async {
    final result = await _auth.signInAnonymously();
    final user = result.user!;
    await _db.collection('users').doc(user.uid).set({
      'uid': user.uid,
      'displayName': 'OPO User ${user.uid.substring(0, 5)}',
      'followers': 0,
      'following': 0,
      'diamonds': 0,
      'updatedAt': FieldValue.serverTimestamp(),
    }, SetOptions(merge: true));
    return result;
  }

  Future<void> signOut() => _auth.signOut();
}
