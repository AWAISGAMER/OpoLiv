
import 'package:cloud_firestore/cloud_firestore.dart';

class RoomService {
  RoomService._();
  static final instance = RoomService._();
  final _db = FirebaseFirestore.instance;

  Stream<QuerySnapshot<Map<String, dynamic>>> liveRooms() {
    return _db.collection('rooms')
      .where('isLive', isEqualTo: true)
      .orderBy('createdAt', descending: true)
      .limit(20)
      .snapshots();
  }

  Future<String> createRoom({
    required String ownerId,
    required String ownerName,
    required String title,
  }) async {
    final ref = await _db.collection('rooms').add({
      'ownerId': ownerId,
      'ownerName': ownerName,
      'title': title,
      'isLive': true,
      'viewerCount': 0,
      'createdAt': FieldValue.serverTimestamp(),
    });
    return ref.id;
  }

  Future<void> endRoom(String roomId) =>
      _db.collection('rooms').doc(roomId).update({'isLive': false});

  Future<void> sendMessage({
    required String roomId,
    required String uid,
    required String name,
    required String text,
  }) {
    return _db.collection('rooms').doc(roomId).collection('messages').add({
      'uid': uid,
      'name': name,
      'text': text.trim(),
      'createdAt': FieldValue.serverTimestamp(),
    });
  }

  Stream<QuerySnapshot<Map<String, dynamic>>> messages(String roomId) {
    return _db.collection('rooms').doc(roomId).collection('messages')
      .orderBy('createdAt', descending: false).limitToLast(100).snapshots();
  }
}
