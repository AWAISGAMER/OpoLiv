
import 'dart:convert';
import 'package:agora_rtc_engine/agora_rtc_engine.dart';
import 'package:http/http.dart' as http;

class AgoraService {
  AgoraService({
    required this.appId,
    required this.tokenServerBaseUrl,
  });

  final String appId;
  final String tokenServerBaseUrl;
  late final RtcEngine engine;

  Future<void> initialize() async {
    engine = createAgoraRtcEngine();
    await engine.initialize(RtcEngineContext(appId: appId));
    await engine.enableAudio();
    await engine.setClientRole(role: ClientRoleType.clientRoleBroadcaster);
  }

  Future<String> fetchToken({
    required String channel,
    required int uid,
  }) async {
    final uri = Uri.parse('$tokenServerBaseUrl/token')
        .replace(queryParameters: {'channel': channel, 'uid': '$uid'});
    final response = await http.get(uri);
    if (response.statusCode != 200) {
      throw Exception('Token server error: ${response.statusCode}');
    }
    final body = jsonDecode(response.body) as Map<String, dynamic>;
    return body['token'] as String;
  }

  Future<void> join({
    required String channel,
    required String token,
    required int uid,
  }) async {
    await engine.joinChannel(
      token: token,
      channelId: channel,
      uid: uid,
      options: const ChannelMediaOptions(
        clientRoleType: ClientRoleType.clientRoleBroadcaster,
        publishMicrophoneTrack: true,
        autoSubscribeAudio: true,
      ),
    );
  }

  Future<void> leave() async {
    await engine.leaveChannel();
    await engine.release();
  }
}
