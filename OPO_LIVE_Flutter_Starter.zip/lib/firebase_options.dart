
import 'package:firebase_core/firebase_core.dart';

/// Replace these placeholders by running:
///   dart pub global activate flutterfire_cli
///   flutterfire configure
///
/// This file is intentionally safe to ship as a template; do not put server
/// secrets (Agora App Certificate, service-account keys, etc.) in this file.
class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    // Android values are placeholders until flutterfire configure is run.
    return const FirebaseOptions(
      apiKey: 'REPLACE_WITH_FIREBASE_API_KEY',
      appId: 'REPLACE_WITH_FIREBASE_APP_ID',
      messagingSenderId: 'REPLACE_WITH_FIREBASE_MESSAGING_SENDER_ID',
      projectId: 'REPLACE_WITH_FIREBASE_PROJECT_ID',
      storageBucket: 'REPLACE_WITH_FIREBASE_STORAGE_BUCKET',
    );
  }
}
