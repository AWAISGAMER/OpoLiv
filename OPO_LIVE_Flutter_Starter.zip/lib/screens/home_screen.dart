
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import '../services/auth_service.dart';
import '../services/room_service.dart';
import 'room_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int tab = 0;

  final demoRooms = const [
    {'title': 'Music Party', 'host': 'Sarah', 'viewers': '3.4K', 'icon': Icons.music_note},
    {'title': 'Gaming Zone', 'host': 'Michael', 'viewers': '2.1K', 'icon': Icons.sports_esports},
    {'title': 'Party Time', 'host': 'Kevin', 'viewers': '4.5K', 'icon': Icons.headphones},
    {'title': 'Girls Talk', 'host': 'Maria', 'viewers': '1.9K', 'icon': Icons.mic},
  ];

  Future<void> _goLive() async {
    final uid = FirebaseAuth.instance.currentUser!.uid;
    final roomId = await RoomService.instance.createRoom(
      ownerId: uid, ownerName: 'Awais', title: 'Awais Live Party',
    );
    if (!mounted) return;
    Navigator.push(context, MaterialPageRoute(
      builder: (_) => RoomScreen(roomId: roomId, channel: roomId, isHost: true),
    ));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF15104B),
        title: const Text('OPO', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 28)),
        actions: [
          IconButton(onPressed: () {}, icon: const Icon(Icons.search)),
          IconButton(onPressed: () {}, icon: const Icon(Icons.notifications_none)),
        ],
      ),
      body: SafeArea(
        child: IndexedStack(
          index: tab,
          children: [
            _home(),
            const Center(child: Text('Explore')),
            const Center(child: Text('Messages')),
            const Center(child: Text('Profile')),
          ],
        ),
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (v) => setState(() => tab = v),
        backgroundColor: const Color(0xFF0A0C24),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.explore_outlined), label: 'Explore'),
          NavigationDestination(icon: Icon(Icons.message_outlined), label: 'Message'),
          NavigationDestination(icon: Icon(Icons.person_outline), label: 'Profile'),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _goLive,
        backgroundColor: const Color(0xFFFF2AA8),
        icon: const Icon(Icons.mic),
        label: const Text('GO LIVE'),
      ),
    );
  }

  Widget _home() {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const Text('Featured', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
        const SizedBox(height: 14),
        Wrap(
          spacing: 10, runSpacing: 10,
          children: ['FOLLOW', 'FEATURED', 'EXPLORE', 'AUDIO'].map((x) =>
            Chip(label: Text(x), backgroundColor: x == 'FEATURED'
              ? const Color(0xFFFF2AA8) : const Color(0xFF171A3B))).toList(),
        ),
        const SizedBox(height: 18),
        StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
          stream: RoomService.instance.liveRooms(),
          builder: (context, snap) {
            final docs = snap.data?.docs ?? [];
            final cards = docs.isNotEmpty ? docs.map((d) => {
              'title': d.data()['title'] ?? 'Live Room',
              'host': d.data()['ownerName'] ?? 'Host',
              'viewers': '${d.data()['viewerCount'] ?? 0}',
              'icon': Icons.mic,
              'id': d.id,
            }).toList() : demoRooms.map((e) => Map<String, dynamic>.from(e)).toList();
            return GridView.builder(
              shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
              itemCount: cards.length, gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2, childAspectRatio: .78, crossAxisSpacing: 12, mainAxisSpacing: 12,
              ),
              itemBuilder: (_, i) {
                final r = cards[i];
                return GestureDetector(
                  onTap: r['id'] == null ? null : () => Navigator.push(context, MaterialPageRoute(
                    builder: (_) => RoomScreen(roomId: r['id'], channel: r['id'], isHost: false),
                  )),
                  child: Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(18),
                      gradient: const LinearGradient(colors: [Color(0xFF32145F), Color(0xFF151A3C)]),
                      border: Border.all(color: const Color(0xFFFF2AA8), width: 1.2),
                    ),
                    padding: const EdgeInsets.all(12),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Expanded(child: Center(child: Icon(r['icon'] as IconData, size: 65, color: const Color(0xFFFF4DB5)))),
                        Text('● LIVE  ${r['viewers']} viewers', style: const TextStyle(color: Color(0xFFFF4DB5), fontWeight: FontWeight.bold)),
                        const SizedBox(height: 7),
                        Text('${r['host']}', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
                        Text('${r['title']}', style: const TextStyle(color: Colors.white70)),
                      ],
                    ),
                  ),
                );
              },
            );
          },
        ),
      ],
    );
  }
}
