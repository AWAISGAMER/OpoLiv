
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import '../services/agora_service.dart';
import '../services/room_service.dart';

class RoomScreen extends StatefulWidget {
  const RoomScreen({
    super.key, required this.roomId, required this.channel, required this.isHost,
  });
  final String roomId;
  final String channel;
  final bool isHost;

  @override State<RoomScreen> createState() => _RoomScreenState();
}

class _RoomScreenState extends State<RoomScreen> {
  // Put your deployed token-server URL here.
  static const tokenServer = String.fromEnvironment('TOKEN_SERVER_URL');
  // Put your Agora App ID here via --dart-define=AGORA_APP_ID=...
  static const appId = String.fromEnvironment('AGORA_APP_ID');

  AgoraService? agora;
  bool joined = false;
  bool muted = false;
  final message = TextEditingController();

  @override
  void initState() {
    super.initState();
    _join();
  }

  Future<void> _join() async {
    if (appId.isEmpty || tokenServer.isEmpty) {
      if (mounted) setState(() => joined = false);
      return;
    }
    final a = AgoraService(appId: appId, tokenServerBaseUrl: tokenServer);
    await a.initialize();
    final uid = DateTime.now().millisecondsSinceEpoch.remainder(2147483647);
    final token = await a.fetchToken(channel: widget.channel, uid: uid);
    await a.join(channel: widget.channel, token: token, uid: uid);
    if (mounted) setState(() { agora = a; joined = true; });
  }

  Future<void> _leave() async {
    await agora?.leave();
    if (widget.isHost) await RoomService.instance.endRoom(widget.roomId);
    if (mounted) Navigator.pop(context);
  }

  @override
  void dispose() {
    message.dispose();
    agora?.leave();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final uid = FirebaseAuth.instance.currentUser!.uid;
    return Scaffold(
      appBar: AppBar(
        title: const Text('OPO LIVE'),
        actions: [IconButton(onPressed: _leave, icon: const Icon(Icons.close))],
      ),
      body: Column(
        children: [
          Expanded(
            child: Container(
              margin: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(26),
                gradient: const LinearGradient(colors: [Color(0xFF2C0B62), Color(0xFF080B24)]),
              ),
              child: Center(
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                  const CircleAvatar(radius: 42, child: Icon(Icons.person, size: 45)),
                  const SizedBox(height: 12),
                  Text(widget.isHost ? 'You are LIVE' : 'You joined the room',
                    style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  Text(joined ? 'Voice connected' : 'Configure Agora token server',
                    style: const TextStyle(color: Colors.white70)),
                  const SizedBox(height: 24),
                  Row(mainAxisSize: MainAxisSize.min, children: [
                    IconButton.filled(onPressed: joined ? () async {
                      setState(() => muted = !muted);
                      await agora?.engine.muteLocalAudioStream(muted);
                    } : null, icon: Icon(muted ? Icons.mic_off : Icons.mic)),
                    const SizedBox(width: 12),
                    IconButton.filled(onPressed: () {}, icon: const Icon(Icons.card_giftcard)),
                  ]),
                ]),
              ),
            ),
          ),
          StreamBuilder(
            stream: RoomService.instance.messages(widget.roomId),
            builder: (context, snap) {
              final docs = snap.data?.docs ?? [];
              return SizedBox(
                height: 180,
                child: ListView(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  children: docs.map((d) => Text(
                    '${d.data()['name'] ?? 'User'}: ${d.data()['text'] ?? ''}',
                    style: const TextStyle(color: Colors.white70),
                  )).toList(),
                ),
              );
            },
          ),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(10),
              child: Row(children: [
                Expanded(child: TextField(controller: message, decoration: const InputDecoration(hintText: 'Say something...'))),
                IconButton(
                  onPressed: () async {
                    if (message.text.trim().isEmpty) return;
                    await RoomService.instance.sendMessage(
                      roomId: widget.roomId, uid: uid, name: 'Awais', text: message.text,
                    );
                    message.clear();
                  },
                  icon: const Icon(Icons.send),
                ),
              ]),
            ),
          ),
        ],
      ),
    );
  }
}
