
import 'package:flutter/material.dart';
import '../services/auth_service.dart';

class LoginScreen extends StatelessWidget {
  const LoginScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xFF080B2A), Color(0xFF5D0B8A), Color(0xFFE51B9B)],
            begin: Alignment.topLeft, end: Alignment.bottomRight,
          ),
        ),
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(28),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.mic_external_on, size: 82, color: Colors.white),
                const SizedBox(height: 16),
                const Text('OPO LIVE', style: TextStyle(fontSize: 40, fontWeight: FontWeight.w900)),
                const SizedBox(height: 8),
                const Text('Voice • Live • Party • Friends', style: TextStyle(color: Colors.white70)),
                const SizedBox(height: 35),
                FilledButton.icon(
                  onPressed: () async {
                    await AuthService.instance.anonymousLogin();
                  },
                  icon: const Icon(Icons.login),
                  label: const Padding(
                    padding: EdgeInsets.symmetric(horizontal: 28, vertical: 14),
                    child: Text('GET STARTED'),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
