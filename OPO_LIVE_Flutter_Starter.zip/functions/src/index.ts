
import {onRequest} from "firebase-functions/v2/https";
import {RtcTokenBuilder, RtcRole} from "agora-access-token";

const APP_ID = process.env.AGORA_APP_ID || "";
const APP_CERTIFICATE = process.env.AGORA_APP_CERTIFICATE || "";

export const token = onRequest({cors: true, region: "us-central1"}, (req, res) => {
  try {
    if (!APP_ID || !APP_CERTIFICATE) {
      res.status(500).json({error: "Agora server configuration missing"});
      return;
    }

    const channel = String(req.query.channel || "");
    const uid = Number(req.query.uid || 0);
    if (!channel || !Number.isInteger(uid) || uid <= 0) {
      res.status(400).json({error: "channel and positive integer uid are required"});
      return;
    }

    const expire = Math.floor(Date.now() / 1000) + 3600;
    const token = RtcTokenBuilder.buildTokenWithUid(
      APP_ID, APP_CERTIFICATE, channel, uid, RtcRole.PUBLISHER, expire
    );
    res.status(200).json({token, expiresAt: expire});
  } catch (e) {
    console.error(e);
    res.status(500).json({error: "Could not create token"});
  }
});
